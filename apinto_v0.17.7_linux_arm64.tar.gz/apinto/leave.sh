#!/bin/bash
set -e
#This script is used to leave the K8S cluster
./apinto leave